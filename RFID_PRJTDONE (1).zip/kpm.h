 //kpm.h
#include "types.h"
u32 ColScan(void);
u32 RowCheck(void);
u32 ColCheck(void);
u32 KeyScan(void);
void Init_KPM(void);
u32 ReadNum(void);
