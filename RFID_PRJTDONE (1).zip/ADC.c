#include <LPC214x.h>

#include "types.h"
#include "define.h"
#include "adc_define.h"
#include "delay.h"
	  


 void Init_ADC(void)
{
PINSEL1|=0x15400000;
  AD0CR=PDN_BIT|CLKDIV<<CLKDIV_START_BIT|0x01;
}

f32 Read_ADC(u8 chNo)
{
  u16 adcVal=0;
        f32 eAR;
        WRITEBYTE(AD0CR,0,chNo);
        SETBIT(AD0CR,ADC_START_BIT);
        delay_us(3);
        while(!READBIT(AD0GDR,DONE_BIT));
        CLRBIT(AD0CR,ADC_START_BIT);
        adcVal=(AD0GDR>>6)&0x3FF;
        eAR=((adcVal*3.3)/1023);
        return eAR;
} 

/*void Init_ADC(void)
{
PINSEL1 |=(1<<24);
AD0CR=(1<<1)|(4<<8)|(1<<21);

}
INT Read_ADC(U8 CHnO)
{
	ADOCR |=(1<<24);
	while(!(ADODR1&(1<<31)));
	return (AD0DR1>>6)&0X3FF;

} */



